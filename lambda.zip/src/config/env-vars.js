process.env.DEV_DB_USERNAME = 'super_admin';
process.env.DEV_DB_PASSWORD = 'Y3Y5RPkbpaqUpKPF';
process.env.DEV_DB_HOST = 'dev1-1pass-db.concbvyykc2k.eu-central-1.rds.amazonaws.com';
process.env.DEV_DB_NAME = 'dev1_1pass_db';
