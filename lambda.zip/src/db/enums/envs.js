module.exports = {
  dev: 'dev',
  preprod: 'preprod',
  prod: 'prod',
};
